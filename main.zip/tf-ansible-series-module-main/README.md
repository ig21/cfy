# Overview

This repository contains a basic Terraform module, designed to be deployed using Cloudify.
